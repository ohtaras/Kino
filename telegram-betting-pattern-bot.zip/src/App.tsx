import { useState, useCallback, useRef } from 'react';
import type { Rule, TelegramTarget, KinoResult, Signal, LogEntry } from './types';
import { DEFAULT_RULES, checkRules } from './utils/rules';
import { fetchLastResult, GAME_OPTIONS } from './utils/opap';
import { sendToAllTargets } from './utils/telegram';
import StatusBar from './components/StatusBar';
import TelegramConfig from './components/TelegramConfig';
import RulesEditor from './components/RulesEditor';
import SignalFeed from './components/SignalFeed';
import ActivityLog from './components/ActivityLog';

type Tab = 'dashboard' | 'rules' | 'telegram' | 'signals' | 'log';

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'dashboard', label: 'Πίνακας', icon: '📊' },
  { id: 'rules', label: 'Κανόνες', icon: '📐' },
  { id: 'telegram', label: 'Telegram', icon: '📨' },
  { id: 'signals', label: 'Σήματα', icon: '🚨' },
  { id: 'log', label: 'Log', icon: '📋' },
];

function makeLog(type: LogEntry['type'], message: string): LogEntry {
  return {
    id: crypto.randomUUID(),
    timestamp: new Date().toLocaleTimeString('el-GR'),
    type,
    message,
  };
}

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isRunning, setIsRunning] = useState(false);
  const [token, setToken] = useState('');
  const [targets, setTargets] = useState<TelegramTarget[]>([
    { id: crypto.randomUUID(), chatId: '', label: 'Κύρια Ομάδα', enabled: true },
  ]);
  const [rules, setRules] = useState<Rule[]>(DEFAULT_RULES);
  const [gameId, setGameId] = useState('1100');
  const [lastDraw, setLastDraw] = useState<KinoResult | null>(null);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const lastDrawNoRef = useRef<number | null>(null);

  const addLog = useCallback((type: LogEntry['type'], message: string) => {
    setLogs((prev) => [...prev.slice(-199), makeLog(type, message)]);
  }, []);

  const handleTick = useCallback(async () => {
    if (!isRunning) return;

    addLog('info', 'Ανάκτηση αποτελεσμάτων OPAP...');

    const result = await fetchLastResult(gameId);
    if (!result || result.winningNumbers.length === 0) {
      addLog('warning', 'Δεν ελήφθησαν αποτελέσματα ή κλήρωση εκτός ωραρίου.');
      return;
    }

    setLastDraw(result);

    if (lastDrawNoRef.current === result.drawNo) {
      addLog('info', `Κλήρωση #${result.drawNo} ήδη ελέγχθηκε. Αναμονή...`);
      return;
    }
    lastDrawNoRef.current = result.drawNo;

    addLog(
      'success',
      `Κλήρωση #${result.drawNo} · [${result.winningNumbers.join(', ')}]`
    );

    const matches = checkRules(rules, result.winningNumbers);

    if (matches.length === 0) {
      addLog('info', 'Κανένας κανόνας δεν ενεργοποιήθηκε.');
      return;
    }

    addLog('success', `🎯 ${matches.length} κανόνας/ες ενεργοποιήθηκε!`);

    for (const match of matches) {
      const msgText =
        `🚨 *${match.ruleName}*\n` +
        `🎯 Root: ${match.root}\n` +
        `🎰 Παίξε: [${match.suggestion.join(', ')}]\n` +
        `⏳ Διάρκεια: ${match.duration} κληρώσεις\n` +
        `📌 Κλήρωση: #${result.drawNo}`;

      const enabledTargets = targets.filter((t) => t.enabled && t.chatId.trim());

      let sentTo: string[] = [];
      if (token && enabledTargets.length > 0) {
        const results = await sendToAllTargets(token, enabledTargets, msgText);
        sentTo = results
          .filter((r) => r.success)
          .map((r) => {
            const target = targets.find((t) => t.chatId.trim() === r.chatId);
            return target?.label ?? r.chatId;
          });

        results.forEach((r) => {
          if (r.success) {
            addLog('success', `✈️ Telegram → ${targets.find((t) => t.chatId.trim() === r.chatId)?.label ?? r.chatId}`);
          } else {
            addLog('error', `Telegram αποτυχία → ${r.chatId}: ${r.error}`);
          }
        });
      } else {
        addLog('warning', 'Κανένα ενεργό Telegram target ή λείπει token.');
      }

      const sig: Signal = {
        id: crypto.randomUUID(),
        timestamp: new Date().toLocaleTimeString('el-GR'),
        ruleName: match.ruleName,
        root: match.root,
        suggestion: match.suggestion,
        duration: match.duration,
        drawNo: result.drawNo,
        sentTo,
      };
      setSignals((prev) => [...prev.slice(-99), sig]);
    }
  }, [isRunning, gameId, rules, targets, token, addLog]);

  const handleManualCheck = async () => {
    addLog('info', '🔍 Χειροκίνητος έλεγχος...');
    const result = await fetchLastResult(gameId);
    if (!result || result.winningNumbers.length === 0) {
      addLog('warning', 'Δεν ελήφθησαν αποτελέσματα.');
      return;
    }
    setLastDraw(result);
    addLog('success', `Κλήρωση #${result.drawNo} · [${result.winningNumbers.join(', ')}]`);

    const matches = checkRules(rules, result.winningNumbers);
    addLog('info', `${matches.length} κανόνας/ες ταιριάζουν.`);
    matches.forEach((m) => {
      addLog('success', `→ ${m.ruleName} root=${m.root} [${m.suggestion.join(',')}]`);
    });
  };

  const newSignalsCount = signals.length;

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col max-w-2xl mx-auto">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-gray-950 border-b border-gray-800 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-lg">
              🎱
            </div>
            <div>
              <h1 className="font-bold text-white leading-tight">KINO Monitor</h1>
              <p className="text-xs text-gray-500">OPAP · Telegram Bot</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Game selector */}
            <select
              value={gameId}
              onChange={(e) => setGameId(e.target.value)}
              className="bg-gray-800 border border-gray-700 text-white text-xs rounded-lg px-2 py-1.5 focus:outline-none focus:border-blue-500"
            >
              {GAME_OPTIONS.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>

            {/* Start/Stop */}
            <button
              onClick={() => {
                setIsRunning((v) => {
                  const next = !v;
                  addLog('info', next ? '▶️ Το monitor ξεκίνησε.' : '⏹️ Το monitor σταμάτησε.');
                  return next;
                });
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                isRunning
                  ? 'bg-red-600 hover:bg-red-500 text-white'
                  : 'bg-green-600 hover:bg-green-500 text-white'
              }`}
            >
              {isRunning ? '⏹ Stop' : '▶ Start'}
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <nav className="flex border-b border-gray-800 bg-gray-950 sticky top-[61px] z-10">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2.5 text-xs font-medium transition-colors relative ${
              activeTab === tab.id
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <span className="block text-base leading-tight">{tab.icon}</span>
            <span className="hidden sm:block">{tab.label}</span>
            {tab.id === 'signals' && newSignalsCount > 0 && (
              <span className="absolute top-1 right-1 bg-red-500 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center">
                {newSignalsCount > 99 ? '99+' : newSignalsCount}
              </span>
            )}
          </button>
        ))}
      </nav>

      {/* Content */}
      <main className="flex-1 p-4 space-y-4 pb-8">
        {/* DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="space-y-4">
            <StatusBar isRunning={isRunning} lastDraw={lastDraw ? {
              drawNo: lastDraw.drawNo,
              drawTime: lastDraw.drawTime,
              numbers: lastDraw.winningNumbers,
            } : null} onTick={handleTick} />

            {/* Quick stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-gray-800 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-blue-400">{signals.length}</p>
                <p className="text-xs text-gray-500 mt-1">Σήματα</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-green-400">
                  {rules.filter((r) => r.enabled && r.trigger.length > 0).length}
                </p>
                <p className="text-xs text-gray-500 mt-1">Κανόνες</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-purple-400">
                  {targets.filter((t) => t.enabled && t.chatId).length}
                </p>
                <p className="text-xs text-gray-500 mt-1">Targets</p>
              </div>
            </div>

            {/* Manual check */}
            <button
              onClick={handleManualCheck}
              className="w-full bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-xl py-3 text-sm font-medium text-gray-300 transition-colors"
            >
              🔍 Χειροκίνητος Έλεγχος Τώρα
            </button>

            {/* Schedule info */}
            <div className="bg-gray-900 border border-gray-700 rounded-xl p-4 space-y-2">
              <p className="text-sm font-semibold text-gray-300">⏱ Χρονισμός Κύκλων</p>
              <p className="text-xs text-gray-500 leading-relaxed">
                Κάθε <span className="text-yellow-400 font-mono">5 λεπτά και 15 δευτερόλεπτα</span> ξεκινώντας από τα μεσάνυχτα:
              </p>
              <div className="font-mono text-xs text-gray-400 grid grid-cols-3 gap-1">
                {['00:00:15','00:05:15','00:10:15','00:15:15','00:20:15','00:25:15'].map((t) => (
                  <span key={t} className="bg-gray-800 px-2 py-1 rounded text-center">{t}</span>
                ))}
              </div>
              <p className="text-xs text-gray-600">... κάθε 315 δευτερόλεπτα, μέχρι τα 23:55:15</p>
            </div>

            {/* Recent signals preview */}
            {signals.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm text-gray-400">🚨 Τελευταία Σήματα</p>
                {[...signals].reverse().slice(0, 3).map((sig) => (
                  <div key={sig.id} className="bg-gray-800 rounded-xl px-3 py-2 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-semibold text-yellow-400">{sig.ruleName}</p>
                      <p className="text-xs text-gray-500">Root {sig.root} · {sig.timestamp}</p>
                    </div>
                    <div className="flex gap-1">
                      {sig.suggestion.slice(0, 4).map((n) => (
                        <span key={n} className="w-6 h-6 rounded-full bg-green-700 text-white text-[10px] font-bold flex items-center justify-center">
                          {n}
                        </span>
                      ))}
                      {sig.suggestion.length > 4 && (
                        <span className="text-xs text-gray-500 self-center">+{sig.suggestion.length - 4}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* RULES */}
        {activeTab === 'rules' && (
          <div className="space-y-3">
            <div className="bg-gray-900 border border-gray-700 rounded-xl p-3">
              <p className="text-xs text-gray-400 leading-relaxed">
                💡 Κάθε κανόνας ορίζει <span className="text-yellow-400">offsets trigger</span> (patterns στα αποτελέσματα) και <span className="text-green-400">offsets πρότασης</span>. Οι αριθμοί εφαρμόζονται για κάθε root 1–80.
              </p>
            </div>
            <RulesEditor rules={rules} onChange={setRules} />
          </div>
        )}

        {/* TELEGRAM */}
        {activeTab === 'telegram' && (
          <div className="space-y-4">
            <div className="bg-gray-900 border border-gray-700 rounded-xl p-3">
              <p className="text-xs text-gray-400 leading-relaxed">
                💡 Χρησιμοποίησε <a href="https://t.me/BotFather" target="_blank" rel="noreferrer" className="text-blue-400">@BotFather</a> για να δημιουργήσεις bot token. Για Chat ID χρησιμοποίησε <a href="https://t.me/userinfobot" target="_blank" rel="noreferrer" className="text-blue-400">@userinfobot</a>.
              </p>
            </div>
            <TelegramConfig
              token={token}
              targets={targets}
              onTokenChange={setToken}
              onTargetsChange={setTargets}
            />
          </div>
        )}

        {/* SIGNALS */}
        {activeTab === 'signals' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-400">🚨 Σήματα ({signals.length})</p>
              {signals.length > 0 && (
                <button
                  onClick={() => setSignals([])}
                  className="text-xs text-gray-600 hover:text-gray-400 transition-colors"
                >
                  Καθαρισμός
                </button>
              )}
            </div>
            <SignalFeed signals={signals} />
          </div>
        )}

        {/* LOG */}
        {activeTab === 'log' && (
          <ActivityLog logs={logs} onClear={() => setLogs([])} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 px-4 py-3 text-center">
        <p className="text-xs text-gray-600">
          KINO OPAP Monitor · Κύκλος κάθε 5:15 · API: api.opap.gr
        </p>
      </footer>
    </div>
  );
}
