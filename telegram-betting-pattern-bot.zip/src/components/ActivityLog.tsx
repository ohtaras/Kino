import type { LogEntry } from '../types';

interface Props {
  logs: LogEntry[];
  onClear: () => void;
}

const typeStyle: Record<LogEntry['type'], string> = {
  info: 'text-gray-400',
  success: 'text-green-400',
  error: 'text-red-400',
  warning: 'text-yellow-400',
};

const typeIcon: Record<LogEntry['type'], string> = {
  info: 'ℹ️',
  success: '✅',
  error: '❌',
  warning: '⚠️',
};

export default function ActivityLog({ logs, onClear }: Props) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-400">
          📋 Log ({logs.length} εγγραφές)
        </p>
        {logs.length > 0 && (
          <button
            onClick={onClear}
            className="text-xs text-gray-600 hover:text-gray-400 transition-colors"
          >
            Καθαρισμός
          </button>
        )}
      </div>

      <div className="bg-gray-900 rounded-xl border border-gray-700 h-64 overflow-y-auto p-3 space-y-1 font-mono text-xs">
        {logs.length === 0 ? (
          <p className="text-gray-600 text-center pt-8">Κανένα log ακόμα...</p>
        ) : (
          [...logs].reverse().map((log) => (
            <div key={log.id} className="flex gap-2">
              <span className="text-gray-600 flex-shrink-0">{log.timestamp}</span>
              <span className="flex-shrink-0">{typeIcon[log.type]}</span>
              <span className={typeStyle[log.type]}>{log.message}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
