import { useState } from 'react';
import type { Rule } from '../types';
import { parseNumberArray } from '../utils/rules';

interface Props {
  rules: Rule[];
  onChange: (rules: Rule[]) => void;
}

export default function RulesEditor({ rules, onChange }: Props) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const updateRule = (id: string, changes: Partial<Rule>) => {
    onChange(rules.map((r) => (r.id === id ? { ...r, ...changes } : r)));
  };

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="space-y-2">
      {rules.map((rule) => (
        <div
          key={rule.id}
          className={`rounded-xl border transition-colors ${
            rule.enabled ? 'border-blue-700 bg-gray-800' : 'border-gray-700 bg-gray-900'
          }`}
        >
          {/* Header */}
          <div className="flex items-center gap-3 px-3 py-2.5">
            <input
              type="checkbox"
              checked={rule.enabled}
              onChange={(e) => updateRule(rule.id, { enabled: e.target.checked })}
              className="accent-blue-500 w-4 h-4 flex-shrink-0"
            />
            <button
              className="flex-1 text-left"
              onClick={() => toggleExpand(rule.id)}
            >
              <span className={`text-sm font-medium ${rule.enabled ? 'text-white' : 'text-gray-500'}`}>
                {rule.name}
              </span>
              {rule.trigger.length > 0 && (
                <span className="ml-2 text-xs text-gray-500">
                  [{rule.trigger.join(', ')}] → {rule.duration} κλ.
                </span>
              )}
            </button>
            <button
              onClick={() => toggleExpand(rule.id)}
              className="text-gray-500 hover:text-gray-300 text-xs px-1"
            >
              {expandedId === rule.id ? '▲' : '▼'}
            </button>
          </div>

          {/* Expanded editor */}
          {expandedId === rule.id && (
            <div className="px-3 pb-3 space-y-3 border-t border-gray-700 pt-3">
              {/* Name */}
              <div>
                <label className="text-xs text-gray-400 block mb-1">Όνομα Κανόνα</label>
                <input
                  value={rule.name}
                  onChange={(e) => updateRule(rule.id, { name: e.target.value })}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1.5 text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Trigger */}
              <div>
                <label className="text-xs text-gray-400 block mb-1">
                  Trigger Offsets
                  <span className="ml-1 text-gray-600">(χωρισμένα με κόμμα, π.χ. 0,1,2,3)</span>
                </label>
                <input
                  value={rule.trigger.join(', ')}
                  onChange={(e) =>
                    updateRule(rule.id, { trigger: parseNumberArray(e.target.value) })
                  }
                  className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1.5 text-white text-sm font-mono focus:outline-none focus:border-blue-500"
                  placeholder="0, 1, 2, 3"
                />
              </div>

              {/* Offsets */}
              <div>
                <label className="text-xs text-gray-400 block mb-1">
                  Suggestion Offsets
                  <span className="ml-1 text-gray-600">(αριθμοί για πρόταση)</span>
                </label>
                <input
                  value={rule.offsets.join(', ')}
                  onChange={(e) =>
                    updateRule(rule.id, { offsets: parseNumberArray(e.target.value) })
                  }
                  className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1.5 text-white text-sm font-mono focus:outline-none focus:border-blue-500"
                  placeholder="0, 1, 2, 3, 10, 11"
                />
              </div>

              {/* Duration */}
              <div>
                <label className="text-xs text-gray-400 block mb-1">
                  Διάρκεια (κληρώσεις)
                </label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={rule.duration}
                  onChange={(e) =>
                    updateRule(rule.id, { duration: parseInt(e.target.value) || 1 })
                  }
                  className="w-24 bg-gray-700 border border-gray-600 rounded px-2 py-1.5 text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Preview */}
              {rule.trigger.length > 0 && (
                <div className="bg-gray-900 rounded-lg p-2 text-xs text-gray-400">
                  <p className="font-semibold text-gray-300 mb-1">Παράδειγμα (root=1):</p>
                  <p>
                    Trigger:{' '}
                    <span className="text-yellow-400">
                      [{rule.trigger.map((o) => 1 + o).filter((n) => n <= 80).join(', ')}]
                    </span>
                  </p>
                  <p>
                    Πρόταση:{' '}
                    <span className="text-green-400">
                      [{rule.offsets.map((o) => 1 + o).filter((n) => n <= 80).join(', ')}]
                    </span>
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
