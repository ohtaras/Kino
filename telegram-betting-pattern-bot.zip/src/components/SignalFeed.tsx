import type { Signal } from '../types';

interface Props {
  signals: Signal[];
}

export default function SignalFeed({ signals }: Props) {
  if (signals.length === 0) {
    return (
      <div className="text-center py-12 text-gray-600">
        <div className="text-4xl mb-3">📡</div>
        <p className="text-sm">Δεν υπάρχουν σήματα ακόμα.</p>
        <p className="text-xs mt-1">Τα σήματα εμφανίζονται εδώ όταν ενεργοποιηθεί κανόνας.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {[...signals].reverse().map((sig) => (
        <div
          key={sig.id}
          className="bg-gray-800 border border-gray-700 rounded-xl p-4 space-y-3"
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="text-yellow-400 font-bold text-sm">🚨 {sig.ruleName}</span>
              <p className="text-gray-500 text-xs mt-0.5">
                Κλήρωση #{sig.drawNo} · {sig.timestamp}
              </p>
            </div>
            <span className="bg-blue-900 text-blue-300 text-xs px-2 py-0.5 rounded-full whitespace-nowrap">
              Root: {sig.root}
            </span>
          </div>

          {/* Numbers */}
          <div>
            <p className="text-gray-400 text-xs mb-1.5">🎰 Πρόταση ({sig.duration} κλ.):</p>
            <div className="flex flex-wrap gap-1.5">
              {sig.suggestion.map((n) => (
                <span
                  key={n}
                  className="w-8 h-8 rounded-full bg-green-700 text-white text-xs font-bold flex items-center justify-center"
                >
                  {n}
                </span>
              ))}
            </div>
          </div>

          {/* Sent to */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-gray-500 text-xs">📨 Εστάλη:</span>
            {sig.sentTo.map((label, i) => (
              <span
                key={i}
                className="text-xs bg-gray-700 text-gray-300 px-2 py-0.5 rounded-full"
              >
                {label}
              </span>
            ))}
            {sig.sentTo.length === 0 && (
              <span className="text-xs text-gray-600">— (κανένας στόχος)</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
