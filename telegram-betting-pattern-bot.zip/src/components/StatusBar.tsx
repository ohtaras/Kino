import { useEffect, useState } from 'react';
import { msUntilNextTick, getNextTicks } from '../utils/scheduler';

interface Props {
  isRunning: boolean;
  lastDraw: { drawNo: number; drawTime: string; numbers: number[] } | null;
  onTick: () => void;
}

export default function StatusBar({ isRunning, lastDraw, onTick }: Props) {
  const [countdown, setCountdown] = useState(0);
  const [nextTicks, setNextTicks] = useState<string[]>([]);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const tick = () => {
      setNow(new Date());
      const ms = msUntilNextTick();
      setCountdown(Math.ceil(ms / 1000));
      setNextTicks(getNextTicks(5));
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  // Fire onTick when countdown hits 0 and running
  useEffect(() => {
    if (!isRunning) return;
    let timeoutId: ReturnType<typeof setTimeout>;

    const schedule = () => {
      const ms = msUntilNextTick();
      timeoutId = setTimeout(() => {
        onTick();
        schedule();
      }, ms);
    };

    schedule();
    return () => clearTimeout(timeoutId);
  }, [isRunning, onTick]);

  const mins = Math.floor(countdown / 60);
  const secs = countdown % 60;

  return (
    <div className="rounded-2xl bg-gray-900 border border-gray-700 p-4 space-y-3">
      {/* Clock row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${isRunning ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
          <span className="text-gray-300 text-sm font-medium">
            {isRunning ? 'ΤΡΕΧΕΙ' : 'ΣΤΑΜΑΤΗΜΕΝΟ'}
          </span>
        </div>
        <div className="text-white font-mono text-lg font-bold">
          {now.toLocaleTimeString('el-GR')}
        </div>
      </div>

      {/* Countdown */}
      <div className="flex items-center justify-between bg-gray-800 rounded-xl px-4 py-3">
        <div>
          <p className="text-gray-400 text-xs uppercase tracking-widest mb-1">Επόμενος Κύκλος σε</p>
          <p className="text-green-400 font-mono text-3xl font-bold">
            {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
          </p>
        </div>
        <div className="text-right">
          <p className="text-gray-400 text-xs uppercase tracking-widest mb-1">Επόμενα Ticks</p>
          <div className="space-y-0.5">
            {nextTicks.map((t, i) => (
              <p key={i} className={`font-mono text-xs ${i === 0 ? 'text-yellow-400 font-bold' : 'text-gray-500'}`}>
                {t}
              </p>
            ))}
          </div>
        </div>
      </div>

      {/* Last draw */}
      {lastDraw && (
        <div className="bg-gray-800 rounded-xl px-4 py-3">
          <p className="text-gray-400 text-xs uppercase tracking-widest mb-2">
            Τελευταία Κλήρωση #{lastDraw.drawNo}
            <span className="ml-2 text-gray-600">· {lastDraw.drawTime}</span>
          </p>
          <div className="flex flex-wrap gap-1.5">
            {lastDraw.numbers.map((n) => (
              <span
                key={n}
                className="w-7 h-7 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center"
              >
                {n}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
