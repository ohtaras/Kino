import { useState } from 'react';
import type { TelegramTarget } from '../types';
import { sendTelegramMessage } from '../utils/telegram';

interface Props {
  token: string;
  targets: TelegramTarget[];
  onTokenChange: (t: string) => void;
  onTargetsChange: (t: TelegramTarget[]) => void;
}

export default function TelegramConfig({ token, targets, onTokenChange, onTargetsChange }: Props) {
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<Record<string, string>>({});

  const addTarget = () => {
    const newTarget: TelegramTarget = {
      id: crypto.randomUUID(),
      chatId: '',
      label: `Στόχος ${targets.length + 1}`,
      enabled: true,
    };
    onTargetsChange([...targets, newTarget]);
  };

  const updateTarget = (id: string, changes: Partial<TelegramTarget>) => {
    onTargetsChange(targets.map((t) => (t.id === id ? { ...t, ...changes } : t)));
  };

  const removeTarget = (id: string) => {
    onTargetsChange(targets.filter((t) => t.id !== id));
  };

  const testTarget = async (target: TelegramTarget) => {
    if (!token) {
      setTestResult((r) => ({ ...r, [target.id]: '❌ Λείπει το Bot Token!' }));
      return;
    }
    setTestingId(target.id);
    const res = await sendTelegramMessage(
      token,
      target.chatId,
      `🔔 *Test μήνυμα* από KINO Monitor\n✅ Το Telegram λειτουργεί σωστά!`
    );
    setTestingId(null);
    setTestResult((r) => ({
      ...r,
      [target.id]: res.success ? '✅ Εστάλη!' : `❌ ${res.error}`,
    }));
  };

  return (
    <div className="space-y-4">
      {/* Bot Token */}
      <div>
        <label className="block text-sm text-gray-400 mb-1">🤖 Bot Token</label>
        <input
          type="password"
          value={token}
          onChange={(e) => onTokenChange(e.target.value)}
          placeholder="123456789:ABCdef..."
          className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm font-mono placeholder-gray-600 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Targets */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-400">📨 Chat IDs ({targets.length})</p>
          <button
            onClick={addTarget}
            className="text-xs bg-blue-600 hover:bg-blue-500 text-white px-3 py-1 rounded-lg transition-colors"
          >
            + Προσθήκη
          </button>
        </div>

        {targets.map((target) => (
          <div key={target.id} className="bg-gray-800 rounded-xl p-3 space-y-2">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={target.enabled}
                onChange={(e) => updateTarget(target.id, { enabled: e.target.checked })}
                className="accent-green-500"
              />
              <input
                value={target.label}
                onChange={(e) => updateTarget(target.id, { label: e.target.value })}
                className="flex-1 bg-gray-700 border border-gray-600 rounded px-2 py-1 text-white text-xs focus:outline-none focus:border-blue-500"
                placeholder="Ετικέτα..."
              />
              <button
                onClick={() => removeTarget(target.id)}
                className="text-red-400 hover:text-red-300 text-xs px-1"
              >
                ✕
              </button>
            </div>
            <div className="flex gap-2">
              <input
                value={target.chatId}
                onChange={(e) => updateTarget(target.id, { chatId: e.target.value })}
                placeholder="Chat ID π.χ. -1001234567890"
                className="flex-1 bg-gray-700 border border-gray-600 rounded px-2 py-1 text-white text-xs font-mono focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={() => testTarget(target)}
                disabled={testingId === target.id || !target.chatId}
                className="text-xs bg-gray-600 hover:bg-gray-500 disabled:opacity-50 text-white px-2 py-1 rounded transition-colors whitespace-nowrap"
              >
                {testingId === target.id ? '⏳' : 'Test'}
              </button>
            </div>
            {testResult[target.id] && (
              <p className="text-xs text-gray-300">{testResult[target.id]}</p>
            )}
          </div>
        ))}

        {targets.length === 0 && (
          <p className="text-center text-gray-600 text-sm py-4">
            Δεν υπάρχουν στόχοι. Κάνε κλικ "+ Προσθήκη".
          </p>
        )}
      </div>
    </div>
  );
}
