export interface Rule {
  id: string;
  name: string;
  trigger: number[];
  offsets: number[];
  duration: number;
  enabled: boolean;
}

export interface TelegramTarget {
  id: string;
  chatId: string;
  label: string;
  enabled: boolean;
}

export interface KinoResult {
  drawNo: number;
  drawTime: string;
  winningNumbers: number[];
}

export interface Signal {
  id: string;
  timestamp: string;
  ruleName: string;
  root: number;
  suggestion: number[];
  duration: number;
  drawNo: number;
  sentTo: string[];
}

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'error' | 'warning';
  message: string;
}

export interface AppConfig {
  token: string;
  targets: TelegramTarget[];
  rules: Rule[];
  isRunning: boolean;
  gameId: string;
}
