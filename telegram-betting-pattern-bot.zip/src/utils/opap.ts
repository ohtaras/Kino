import type { KinoResult } from '../types';

export const GAME_OPTIONS = [
  { id: '1100', name: 'Kino' },
  { id: '5103', name: 'Lotto' },
  { id: '5104', name: 'Joker' },
  { id: '2100', name: 'Super 3' },
  { id: '5106', name: 'Extra 5' },
];

export async function fetchLastResult(gameId: string): Promise<KinoResult | null> {
  try {
    const url = `https://api.opap.gr/draws/v3.0/${gameId}/last-result-and-active`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    const draw = data?.last;
    if (!draw) return null;

    // Kino uses winningNumbers, others use results
    const numbers: number[] =
      draw.winningNumbers?.list ??
      draw.winningNumbers ??
      draw.results ??
      [];

    return {
      drawNo: draw.drawId ?? draw.drawNo ?? 0,
      drawTime: draw.drawTime ?? '',
      winningNumbers: Array.isArray(numbers) ? numbers.map(Number) : [],
    };
  } catch (e) {
    console.error('OPAP fetch error:', e);
    return null;
  }
}
