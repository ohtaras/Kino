import type { Rule } from '../types';

export const DEFAULT_RULES: Rule[] = [
  {
    id: 'rule1',
    name: 'ΚΑΝΟΝΑΣ 1 (Οριζόντιο)',
    trigger: [0, 1, 2, 3],
    offsets: [0, 1, 2, 3, 10, 11],
    duration: 4,
    enabled: true,
  },
  {
    id: 'rule2',
    name: 'ΚΑΝΟΝΑΣ 2 (Τετράγωνο)',
    trigger: [0, 1, 10, 11, 20, 21],
    offsets: [0, 1, 10, 11, 20, 21],
    duration: 2,
    enabled: true,
  },
  {
    id: 'rule3',
    name: 'ΚΑΝΟΝΑΣ 3 (Στήλη)',
    trigger: [0, 10, 20, 30],
    offsets: [0, 10, 20, 30, 40, 50],
    duration: 2,
    enabled: true,
  },
  {
    id: 'rule4',
    name: 'ΚΑΝΟΝΑΣ 4 (Σταυρόνημα)',
    trigger: [0, 1, 2, 10, 20],
    offsets: [0, 1, 2, 10, 11, 12],
    duration: 2,
    enabled: true,
  },
  {
    id: 'rule5',
    name: 'ΚΑΝΟΝΑΣ 5',
    trigger: [],
    offsets: [],
    duration: 0,
    enabled: false,
  },
  {
    id: 'rule6',
    name: 'ΚΑΝΟΝΑΣ 6',
    trigger: [],
    offsets: [],
    duration: 0,
    enabled: false,
  },
  {
    id: 'rule7',
    name: 'ΚΑΝΟΝΑΣ 7',
    trigger: [],
    offsets: [],
    duration: 0,
    enabled: false,
  },
  {
    id: 'rule8',
    name: 'ΚΑΝΟΝΑΣ 8',
    trigger: [],
    offsets: [],
    duration: 0,
    enabled: false,
  },
  {
    id: 'rule9',
    name: 'ΚΑΝΟΝΑΣ 9',
    trigger: [],
    offsets: [],
    duration: 0,
    enabled: false,
  },
  {
    id: 'rule10',
    name: 'ΚΑΝΟΝΑΣ 10',
    trigger: [],
    offsets: [],
    duration: 0,
    enabled: false,
  },
];

export interface RuleMatch {
  ruleName: string;
  root: number;
  suggestion: number[];
  duration: number;
}

export function checkRules(rules: Rule[], winningNumbers: number[]): RuleMatch[] {
  const winSet = new Set(winningNumbers);
  const matches: RuleMatch[] = [];

  for (const rule of rules) {
    if (!rule.enabled || rule.trigger.length === 0) continue;

    for (let root = 1; root <= 80; root++) {
      const triggerNums = rule.trigger
        .map((off) => root + off)
        .filter((n) => n >= 1 && n <= 80);

      if (
        triggerNums.length === rule.trigger.length &&
        triggerNums.every((n) => winSet.has(n))
      ) {
        const suggestion = rule.offsets
          .map((off) => root + off)
          .filter((n) => n >= 1 && n <= 80);

        matches.push({
          ruleName: rule.name,
          root,
          suggestion: suggestion.sort((a, b) => a - b),
          duration: rule.duration,
        });
      }
    }
  }

  return matches;
}

export function parseNumberArray(input: string): number[] {
  return input
    .split(/[\s,;]+/)
    .map((s) => parseInt(s.trim(), 10))
    .filter((n) => !isNaN(n));
}
