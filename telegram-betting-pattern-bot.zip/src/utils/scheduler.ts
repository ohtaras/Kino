/**
 * Calculates the milliseconds until the next 5:15 interval tick.
 * Schedule: 00:00:15, 00:05:15, 00:10:15, 00:15:15, ... (every 315 seconds, starting at 15s past midnight)
 */
export function msUntilNextTick(): number {
  const now = new Date();
  const secondsSinceMidnight =
    now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  const ms = now.getMilliseconds();

  const INTERVAL = 315; // 5 min 15 sec
  const OFFSET = 15;    // start at 00:00:15

  // Adjusted seconds: how far are we from the 0-based interval with 15s offset
  const adjusted = secondsSinceMidnight - OFFSET;
  const remainder = ((adjusted % INTERVAL) + INTERVAL) % INTERVAL;
  const waitSeconds = INTERVAL - remainder;

  // Convert to ms, subtracting current ms for precision
  return waitSeconds * 1000 - ms;
}

/**
 * Returns a human-readable string showing the next N tick times.
 */
export function getNextTicks(count: number = 5): string[] {
  const now = new Date();
  const INTERVAL = 315;
  const OFFSET = 15;
  const ticks: string[] = [];

  const secondsSinceMidnight =
    now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  const adjusted = secondsSinceMidnight - OFFSET;
  const remainder = ((adjusted % INTERVAL) + INTERVAL) % INTERVAL;
  let waitSeconds = INTERVAL - remainder;

  for (let i = 0; i < count; i++) {
    const nextSec = (secondsSinceMidnight + waitSeconds + i * INTERVAL) % 86400;
    const h = Math.floor(nextSec / 3600);
    const m = Math.floor((nextSec % 3600) / 60);
    const s = nextSec % 60;
    ticks.push(
      `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    );
  }
  return ticks;
}
