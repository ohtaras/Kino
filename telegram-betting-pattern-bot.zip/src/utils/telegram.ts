export interface TelegramSendResult {
  chatId: string;
  success: boolean;
  error?: string;
}

export async function sendTelegramMessage(
  token: string,
  chatId: string,
  text: string
): Promise<TelegramSendResult> {
  if (!token || !chatId) {
    return { chatId, success: false, error: 'Missing token or chat ID' };
  }
  try {
    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'Markdown' }),
    });
    const data = await res.json();
    if (!data.ok) {
      return { chatId, success: false, error: data.description ?? 'Unknown error' };
    }
    return { chatId, success: true };
  } catch (e: unknown) {
    return { chatId, success: false, error: String(e) };
  }
}

export async function sendToAllTargets(
  token: string,
  targets: Array<{ chatId: string; label: string; enabled: boolean }>,
  text: string
): Promise<TelegramSendResult[]> {
  const enabled = targets.filter((t) => t.enabled && t.chatId.trim());
  const results = await Promise.all(
    enabled.map((t) => sendTelegramMessage(token, t.chatId.trim(), text))
  );
  return results;
}
